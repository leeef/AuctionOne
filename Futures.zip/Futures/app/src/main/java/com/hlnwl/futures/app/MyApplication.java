package com.hlnwl.futures.app;


import com.hlnwl.futures.base.UIApplication;

/**
 * 版权：hlnwl 版权所有
 *
 * @author yougui
 *         版本：1.0
 *         创建日期：2019
 *         描述：
 */
public class MyApplication extends UIApplication {
    public static MyApplication   mContext;
    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;

    }
    public static MyApplication getmContext() {
        return mContext;
    }
}
